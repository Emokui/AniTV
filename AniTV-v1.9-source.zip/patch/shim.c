extern void *dlopen(const char *, int);
extern void *dlsym(void *, const char *);
extern int dlclose(void *);
extern char *mpv_get_property_string(void *, const char *);
extern void mpv_free(void *);
extern int mpv_get_property(void *, const char *, int, void *);
extern void mpv_free_node_contents(void *);
extern int tvplayer_open(void *, const char *, const char *, const char *);
extern void tvplayer_forget(void *);
static int equal(const char *a, const char *b) {
    if (!a || !b) return a == b;
    while (*a && *a == *b) { ++a; ++b; }
    return *a == *b;
}
static void *resolve(const char *name) {
    static void *handle;
    void *loaded = __atomic_load_n(&handle, __ATOMIC_ACQUIRE);
    if (!loaded) {
        loaded = dlopen("liborg.so", 2);
        if (!loaded) return (void *)0;
        void *expected = (void *)0;
        if (!__atomic_compare_exchange_n(&handle, &expected, loaded, 0, __ATOMIC_RELEASE, __ATOMIC_ACQUIRE)) {
            dlclose(loaded); loaded = expected;
        }
    }
    return dlsym(loaded, name);
}
static const char *background_value(const char *name) {
    if (equal(name, "vo") || equal(name, "ao")) return "null";
    if (equal(name, "vid") || equal(name, "hwdec") || equal(name, "cache")) return "no";
    if (equal(name, "aid")) return "auto";
    if (equal(name, "pause") || equal(name, "mute")) return "yes";
    if (equal(name, "volume") || equal(name, "demuxer-readahead-secs")) return "0";
    if (equal(name, "demuxer-max-bytes")) return "1048576";
    return (void *)0;
}
int mpv_set_property(void *ctx, const char *name, int format, void *data) {
    typedef int (*fn_t)(void *, const char *, int, void *);
    fn_t fn = (fn_t)resolve("org_set_property");
    if (!fn) return -20;
    const char *value = background_value(name);
    return value ? fn(ctx, name, 1, &value) : fn(ctx, name, format, data);
}
int mpv_set_property_string(void *ctx, const char *name, const char *value) {
    return mpv_set_property(ctx, name, 1, &value);
}
int mpv_set_property_async(void *ctx, unsigned long long reply, const char *name, int format, void *data) {
    typedef int (*fn_t)(void *, unsigned long long, const char *, int, void *);
    fn_t fn = (fn_t)resolve("org_set_property_async");
    if (!fn) return -20;
    const char *value = background_value(name);
    return value ? fn(ctx, reply, name, 1, &value) : fn(ctx, reply, name, format, data);
}
int mpv_set_option(void *ctx, const char *name, int format, void *data) {
    typedef int (*fn_t)(void *, const char *, int, void *);
    fn_t fn = (fn_t)resolve("org_set_option");
    if (!fn) return -20;
    const char *value = background_value(name);
    return value ? fn(ctx, name, 1, &value) : fn(ctx, name, format, data);
}
int mpv_set_option_string(void *ctx, const char *name, const char *value) {
    return mpv_set_option(ctx, name, 1, &value);
}
static const char **map_command(const char **args, const char **out) {
    if (!args || !args[0] || !args[1] || !args[2]) return args;
    if (!equal(args[0], "set") && !equal(args[0], "set_property") && !equal(args[0], "set_property_string")) return args;
    const char *value = background_value(args[1]);
    if (!value) return args;
    int i = 0;
    for (; i < 31 && args[i]; ++i) out[i] = args[i];
    if (i == 31) return args;
    out[i] = (void *)0; out[2] = value;
    return out;
}
int mpv_command(void *ctx, const char **args) {
    typedef int (*fn_t)(void *, const char **);
    fn_t fn = (fn_t)resolve("org_command"); const char *out[32];
    return fn ? fn(ctx, map_command(args, out)) : -20;
}
int mpv_command_async(void *ctx, unsigned long long reply, const char **args) {
    typedef int (*fn_t)(void *, unsigned long long, const char **);
    fn_t fn = (fn_t)resolve("org_command_async"); const char *out[32];
    return fn ? fn(ctx, reply, map_command(args, out)) : -20;
}
int mpv_command_ret(void *ctx, const char **args, void *result) {
    typedef int (*fn_t)(void *, const char **, void *);
    fn_t fn = (fn_t)resolve("org_command_ret"); const char *out[32];
    return fn ? fn(ctx, map_command(args, out), result) : -20;
}
struct node;
struct list { int num; struct node *values; char **keys; };
struct node { union { char *string; long long integer; struct list *list; } value; int format; };
struct event { int id, error; unsigned long long reply; void *data; };
struct event *mpv_wait_event(void *ctx, double timeout) {
    typedef struct event *(*fn_t)(void *, double);
    fn_t fn = (fn_t)resolve("org_wait_event");
    if (!fn) return (void *)0;
    struct event *event = fn(ctx, timeout);
    if (event && event->id == 8) {
        char *path = mpv_get_property_string(ctx, "path");
        int http = path && path[0]=='h' && path[1]=='t' && path[2]=='t' && path[3]=='p' &&
                   (path[4]==':' || (path[4]=='s' && path[5]==':'));
        if (http) {
            typedef int (*set_fn)(void *, const char *, int, void *);
            set_fn set = (set_fn)resolve("org_set_property");
            const char *null_audio = "null";
            if (set) set(ctx, "ao", 1, &null_audio);
            char *title = mpv_get_property_string(ctx, "media-title");
            char headers[16384]; int used = 0;
            struct node header_list = {0};
            if (mpv_get_property(ctx, "http-header-fields", 6, &header_list) >= 0) {
                if (header_list.format == 7 && header_list.value.list) {
                    struct list *list = header_list.value.list;
                    for (int i=0; i<list->num; ++i) {
                        struct node *item = list->values + i;
                        if (item->format != 1 || !item->value.string) continue;
                        const char *s = item->value.string;
                        while (*s && used < (int)sizeof(headers)-2) headers[used++] = *s++;
                        if (used < (int)sizeof(headers)-2) headers[used++]='\n';
                    }
                }
                mpv_free_node_contents(&header_list);
            }
            headers[used]=0;
            tvplayer_open(ctx, path, title ? title : "AniCh TV", headers);
            if (title) mpv_free(title);
        }
        if (path) mpv_free(path);
    }
    return event;
}
void mpv_destroy(void *ctx) {
    typedef void (*fn_t)(void *);
    tvplayer_forget(ctx); fn_t fn=(fn_t)resolve("org_destroy"); if(fn)fn(ctx);
}
void mpv_terminate_destroy(void *ctx) {
    typedef void (*fn_t)(void *);
    tvplayer_forget(ctx); fn_t fn=(fn_t)resolve("org_terminate_destroy"); if(fn)fn(ctx);
}
