.class public Lw0/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:J

.field public b:J

.field public c:Landroid/view/Surface;

.field public final d:Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

.field public e:Z

.field public final f:Ljava/lang/reflect/Method;

.field public final g:Ljava/lang/reflect/Method;

.field public h:Z

.field public i:J

.field public j:Lio/flutter/plugin/common/MethodChannel;

.field public k:Lio/flutter/view/TextureRegistry;

.field public final l:Ljava/lang/Object;


# direct methods
.method public constructor <init>(JLio/flutter/plugin/common/MethodChannel;Lio/flutter/view/TextureRegistry;)V
    .locals 8

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    const-string v2, "media_kit"

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    const-wide/16 v3, 0x0

    .line 9
    .line 10
    iput-wide v3, p0, Lw0/e;->a:J

    .line 11
    .line 12
    iput-wide v3, p0, Lw0/e;->b:J

    .line 13
    .line 14
    new-instance v3, Ljava/lang/Object;

    .line 15
    .line 16
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v3, p0, Lw0/e;->l:Ljava/lang/Object;

    .line 20
    .line 21
    iput-wide p1, p0, Lw0/e;->i:J

    .line 22
    .line 23
    iput-object p3, p0, Lw0/e;->j:Lio/flutter/plugin/common/MethodChannel;

    .line 24
    .line 25
    iput-object p4, p0, Lw0/e;->k:Lio/flutter/view/TextureRegistry;

    .line 26
    .line 27
    :try_start_0
    iput-boolean v1, p0, Lw0/e;->e:Z

    .line 28
    .line 29
    iput-boolean v1, p0, Lw0/e;->h:Z

    .line 30
    .line 31
    const-class v3, Lcom/alexmercerind/mediakitandroidhelper/MediaKitAndroidHelper;

    .line 32
    .line 33
    sget v4, Lcom/alexmercerind/mediakitandroidhelper/MediaKitAndroidHelper;->a:I

    .line 34
    .line 35
    const-string v4, "newGlobalObjectRef"

    .line 36
    .line 37
    new-array v5, v0, [Ljava/lang/Class;

    .line 38
    .line 39
    const-class v6, Ljava/lang/Object;

    .line 40
    .line 41
    aput-object v6, v5, v1

    .line 42
    .line 43
    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    iput-object v4, p0, Lw0/e;->f:Ljava/lang/reflect/Method;

    .line 48
    .line 49
    const-string v5, "deleteGlobalObjectRef"

    .line 50
    .line 51
    new-array v6, v0, [Ljava/lang/Class;

    .line 52
    .line 53
    sget-object v7, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 54
    .line 55
    aput-object v7, v6, v1

    .line 56
    .line 57
    invoke-virtual {v3, v5, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    iput-object v3, p0, Lw0/e;->g:Ljava/lang/reflect/Method;

    .line 62
    .line 63
    invoke-virtual {v4, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v3, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 67
    .line 68
    .line 69
    invoke-interface {p4}, Lio/flutter/view/TextureRegistry;->createSurfaceTexture()Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

    .line 70
    .line 71
    .line 72
    move-result-object p4

    .line 73
    iput-object p4, p0, Lw0/e;->d:Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

    invoke-interface {p4}, Lio/flutter/view/TextureRegistry$TextureEntry;->id()J
    move-result-wide v3
    iput-wide v3, p0, Lw0/e;->a:J

    .line 74
    .line 75
    :try_start_1
    iget-boolean p4, p0, Lw0/e;->e:Z

    .line 76
    .line 77
    if-nez p4, :cond_1

    .line 78
    .line 79
    invoke-virtual {p0}, Lw0/e;->f()Lio/flutter/embedding/engine/FlutterJNI;

    .line 80
    .line 81
    .line 82
    move-result-object p4

    .line 83
    if-eqz p4, :cond_0

    .line 84
    .line 85
    const/4 p4, 0x1

    .line 86
    goto :goto_0

    .line 87
    :cond_0
    const/4 p4, 0x0

    .line 88
    :goto_0
    iput-boolean p4, p0, Lw0/e;->e:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 89
    .line 90
    goto :goto_1

    .line 91
    :catchall_0
    move-exception p4

    .line 92
    invoke-virtual {p4}, Ljava/lang/Throwable;->printStackTrace()V

    .line 93
    .line 94
    .line 95
    :cond_1
    :goto_1
    iput-boolean v1, p0, Lw0/e;->e:Z
    sget-object p4, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 96
    .line 97
    iget-boolean v3, p0, Lw0/e;->e:Z

    .line 98
    .line 99
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    new-array v4, v0, [Ljava/lang/Object;

    .line 104
    .line 105
    aput-object v3, v4, v1

    .line 106
    .line 107
    const-string v3, "flutterJNIAPIAvailable = %b"

    .line 108
    .line 109
    invoke-static {p4, v3, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v3

    .line 113
    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 114
    .line 115
    .line 116
    iget-boolean v3, p0, Lw0/e;->e:Z

    .line 117
    .line 118
    if-eqz v3, :cond_2

    .line 119
    .line 120
    iget-object v3, p0, Lw0/e;->d:Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

    .line 121
    .line 122
    invoke-interface {v3}, Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;->surfaceTexture()Landroid/graphics/SurfaceTexture;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    new-instance v4, Lw0/c;

    .line 127
    .line 128
    invoke-direct {v4, p0, p1, p2, p3}, Lw0/c;-><init>(Lw0/e;JLio/flutter/plugin/common/MethodChannel;)V

    .line 129
    .line 130
    .line 131
    new-instance p1, Landroid/os/Handler;

    .line 132
    .line 133
    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    .line 134
    .line 135
    .line 136
    invoke-virtual {v3, v4, p1}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;Landroid/os/Handler;)V

    .line 137
    .line 138
    .line 139
    goto :goto_2

    .line 140
    :cond_2
    iget-boolean v3, p0, Lw0/e;->h:Z

    .line 141
    .line 142
    if-nez v3, :cond_3

    .line 143
    .line 144
    iput-boolean v0, p0, Lw0/e;->h:Z

    .line 145
    .line 146
    new-instance v3, Ljava/util/HashMap;

    .line 147
    .line 148
    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    .line 149
    .line 150
    .line 151
    iget-wide v4, p0, Lw0/e;->a:J

    .line 152
    .line 153
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 154
    .line 155
    .line 156
    move-result-object v4

    .line 157
    const-string v5, "id"

    .line 158
    .line 159
    invoke-virtual {v3, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    iget-wide v4, p0, Lw0/e;->b:J

    .line 163
    .line 164
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 165
    .line 166
    .line 167
    move-result-object v4

    .line 168
    const-string v5, "wid"

    .line 169
    .line 170
    invoke-virtual {v3, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    const-string p2, "handle"

    .line 178
    .line 179
    invoke-virtual {v3, p2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    const-string p1, "VideoOutput.WaitUntilFirstFrameRenderedNotify"

    .line 183
    .line 184
    invoke-virtual {p3, p1, v3}, Lio/flutter/plugin/common/MethodChannel;->invokeMethod(Ljava/lang/String;Ljava/lang/Object;)V

    .line 185
    .line 186
    .line 187
    :cond_3
    :goto_2
    :try_start_2
    iget-object p1, p0, Lw0/e;->d:Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

    .line 188
    .line 189
    invoke-interface {p1}, Lio/flutter/view/TextureRegistry$TextureEntry;->id()J

    .line 190
    .line 191
    .line 192
    move-result-wide p1

    .line 193
    iput-wide p1, p0, Lw0/e;->a:J

    .line 194
    .line 195
    const-string p3, "com.alexmercerind.media_kit_video.VideoOutput: id = %d"

    .line 196
    .line 197
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    new-array p2, v0, [Ljava/lang/Object;

    .line 202
    .line 203
    aput-object p1, p2, v1

    .line 204
    .line 205
    invoke-static {p4, p3, p2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object p1

    .line 209
    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 210
    .line 211
    .line 212
    goto :goto_3

    .line 213
    :catchall_1
    move-exception p1

    .line 214
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 215
    .line 216
    .line 217
    :goto_3
    return-void

    .line 218
    :catchall_2
    const-string p1, "package:media_kit_libs_android_video missing. Make sure you have added it to pubspec.yaml."

    .line 219
    .line 220
    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 221
    .line 222
    .line 223
    new-instance p1, Ljava/lang/RuntimeException;

    .line 224
    .line 225
    const-string p2, "Failed to initialize com.alexmercerind.media_kit_video.VideoOutput."

    .line 226
    .line 227
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    throw p1
.end method

.method public static synthetic a(Lw0/e;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lw0/e;->g()V

    return-void
.end method

.method public static synthetic b(Lw0/e;JLio/flutter/plugin/common/MethodChannel;Landroid/graphics/SurfaceTexture;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2, p3, p4}, Lw0/e;->h(JLio/flutter/plugin/common/MethodChannel;Landroid/graphics/SurfaceTexture;)V

    return-void
.end method


# virtual methods
.method public final c()V
    .locals 3

    .line 1
    :try_start_0
    iget-object v0, p0, Lw0/e;->c:Landroid/view/Surface;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, Landroid/view/Surface;->lockCanvas(Landroid/graphics/Rect;)Landroid/graphics/Canvas;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sget-object v1, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    invoke-virtual {v0, v2, v1}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Lw0/e;->c:Landroid/view/Surface;

    .line 15
    .line 16
    invoke-virtual {v1, v0}, Landroid/view/Surface;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catchall_0
    move-exception v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 22
    .line 23
    .line 24
    :goto_0
    return-void
.end method

.method public d()J
    .locals 9

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    iget-object v2, p0, Lw0/e;->l:Ljava/lang/Object;

    .line 4
    .line 5
    monitor-enter v2

    .line 6
    const/4 v3, 0x0

    .line 7
    :try_start_0
    iget-object v4, p0, Lw0/e;->c:Landroid/view/Surface;

    .line 8
    .line 9
    if-eqz v4, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Lw0/e;->c()V

    .line 12
    .line 13
    .line 14
    iget-object v4, p0, Lw0/e;->c:Landroid/view/Surface;

    .line 15
    .line 16
    invoke-virtual {v4}, Landroid/view/Surface;->release()V

    .line 17
    .line 18
    .line 19
    iput-object v3, p0, Lw0/e;->c:Landroid/view/Surface;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :catchall_0
    move-exception v4

    .line 23
    goto :goto_1

    .line 24
    :cond_0
    :goto_0
    iget-wide v4, p0, Lw0/e;->b:J

    .line 25
    .line 26
    const-wide/16 v6, 0x0

    .line 27
    .line 28
    cmp-long v8, v4, v6

    .line 29
    .line 30
    if-eqz v8, :cond_1

    .line 31
    .line 32
    iget-object v8, p0, Lw0/e;->g:Ljava/lang/reflect/Method;

    .line 33
    .line 34
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    new-array v5, v1, [Ljava/lang/Object;

    .line 39
    .line 40
    aput-object v4, v5, v0

    .line 41
    .line 42
    invoke-virtual {v8, v3, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    iput-wide v6, p0, Lw0/e;->b:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    .line 47
    goto :goto_2

    .line 48
    :goto_1
    :try_start_1
    invoke-virtual {v4}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 49
    .line 50
    .line 51
    :cond_1
    :goto_2
    :try_start_2
    new-instance v4, Landroid/view/Surface;

    .line 52
    .line 53
    iget-object v5, p0, Lw0/e;->d:Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

    .line 54
    .line 55
    invoke-interface {v5}, Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;->surfaceTexture()Landroid/graphics/SurfaceTexture;

    .line 56
    .line 57
    .line 58
    move-result-object v5

    .line 59
    invoke-direct {v4, v5}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    .line 60
    .line 61
    .line 62
    iput-object v4, p0, Lw0/e;->c:Landroid/view/Surface;

    .line 63
    .line 64
    iget-object v5, p0, Lw0/e;->f:Ljava/lang/reflect/Method;

    .line 65
    .line 66
    new-array v1, v1, [Ljava/lang/Object;

    .line 67
    .line 68
    aput-object v4, v1, v0

    .line 69
    .line 70
    invoke-virtual {v5, v3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    check-cast v0, Ljava/lang/Long;

    .line 75
    .line 76
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 77
    .line 78
    .line 79
    move-result-wide v0

    .line 80
    iput-wide v0, p0, Lw0/e;->b:J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 81
    .line 82
    goto :goto_3

    .line 83
    :catchall_1
    move-exception v0

    .line 84
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 85
    .line 86
    .line 87
    :goto_3
    iget-wide v0, p0, Lw0/e;->b:J

    .line 88
    .line 89
    monitor-exit v2

    .line 90
    return-wide v0

    .line 91
    :catchall_2
    move-exception v0

    .line 92
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 93
    throw v0
.end method

.method public e()V
    .locals 4

    .line 1
    :try_start_0
    iget-object v0, p0, Lw0/e;->d:Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

    .line 2
    .line 3
    invoke-interface {v0}, Lio/flutter/view/TextureRegistry$TextureEntry;->release()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    .line 5
    .line 6
    goto :goto_0

    .line 7
    :catchall_0
    move-exception v0

    .line 8
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 9
    .line 10
    .line 11
    :goto_0
    :try_start_1
    iget-object v0, p0, Lw0/e;->c:Landroid/view/Surface;

    .line 12
    .line 13
    invoke-virtual {v0}, Landroid/view/Surface;->release()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 14
    .line 15
    .line 16
    goto :goto_1

    .line 17
    :catchall_1
    move-exception v0

    .line 18
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 19
    .line 20
    .line 21
    :goto_1
    :try_start_2
    new-instance v0, Landroid/os/Handler;

    .line 22
    .line 23
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 28
    .line 29
    .line 30
    new-instance v1, Lw0/d;

    .line 31
    .line 32
    invoke-direct {v1, p0}, Lw0/d;-><init>(Lw0/e;)V

    .line 33
    .line 34
    .line 35
    const-wide/16 v2, 0x1388

    .line 36
    .line 37
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 38
    .line 39
    .line 40
    goto :goto_2

    .line 41
    :catchall_2
    move-exception v0

    .line 42
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 43
    .line 44
    .line 45
    :goto_2
    return-void
.end method

.method public final f()Lio/flutter/embedding/engine/FlutterJNI;
    .locals 5

    .line 1
    :try_start_0
    sget-object v0, Lw0/a;->i:Landroid/app/Activity;

    .line 2
    .line 3
    sget v1, Lio/flutter/embedding/android/FlutterActivity;->FLUTTER_VIEW_ID:I

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lio/flutter/embedding/android/FlutterView;

    .line 10
    .line 11
    if-nez v0, :cond_1

    .line 12
    .line 13
    sget-object v1, Lw0/a;->i:Landroid/app/Activity;

    .line 14
    .line 15
    sget v2, Lio/flutter/embedding/android/FlutterFragmentActivity;->FRAGMENT_CONTAINER_ID:I

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Landroid/widget/FrameLayout;

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    :goto_0
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    if-ge v2, v3, :cond_1

    .line 29
    .line 30
    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    instance-of v4, v3, Lio/flutter/embedding/android/FlutterView;

    .line 35
    .line 36
    if-eqz v4, :cond_0

    .line 37
    .line 38
    move-object v0, v3

    .line 39
    check-cast v0, Lio/flutter/embedding/android/FlutterView;

    .line 40
    .line 41
    goto :goto_1

    .line 42
    :catchall_0
    move-exception v0

    .line 43
    goto :goto_2

    .line 44
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_1
    :goto_1
    invoke-virtual {v0}, Lio/flutter/embedding/android/FlutterView;->getAttachedFlutterEngine()Lio/flutter/embedding/engine/FlutterEngine;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    const-string v2, "flutterJNI"

    .line 56
    .line 57
    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    const/4 v2, 0x1

    .line 62
    invoke-virtual {v1, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Lio/flutter/embedding/engine/FlutterJNI;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 70
    .line 71
    return-object v0

    .line 72
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 73
    .line 74
    .line 75
    const/4 v0, 0x0

    .line 76
    return-object v0
.end method

.method public final synthetic g()V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    :try_start_0
    iget-object v2, p0, Lw0/e;->g:Ljava/lang/reflect/Method;

    .line 4
    .line 5
    iget-wide v3, p0, Lw0/e;->b:J

    .line 6
    .line 7
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    new-array v4, v1, [Ljava/lang/Object;

    .line 12
    .line 13
    aput-object v3, v4, v0

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    invoke-virtual {v2, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    const-string v2, "media_kit"

    .line 20
    .line 21
    sget-object v3, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 22
    .line 23
    const-string v4, "com.alexmercerind.mediakitandroidhelper.MediaKitAndroidHelper.deleteGlobalObjectRef: %d"

    .line 24
    .line 25
    iget-wide v5, p0, Lw0/e;->b:J

    .line 26
    .line 27
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    new-array v1, v1, [Ljava/lang/Object;

    .line 32
    .line 33
    aput-object v5, v1, v0

    .line 34
    .line 35
    invoke-static {v3, v4, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :catchall_0
    move-exception v0

    .line 44
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 45
    .line 46
    .line 47
    :goto_0
    return-void
.end method

.method public final synthetic h(JLio/flutter/plugin/common/MethodChannel;Landroid/graphics/SurfaceTexture;)V
    .locals 4

    .line 1
    const/4 p4, 0x1

    .line 2
    iget-object v0, p0, Lw0/e;->l:Ljava/lang/Object;

    .line 3
    .line 4
    monitor-enter v0

    .line 5
    :try_start_0
    iget-boolean v1, p0, Lw0/e;->h:Z

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    iput-boolean p4, p0, Lw0/e;->h:Z

    .line 10
    .line 11
    new-instance v1, Ljava/util/HashMap;

    .line 12
    .line 13
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 14
    .line 15
    .line 16
    const-string v2, "handle"

    .line 17
    .line 18
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    invoke-virtual {v1, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    const-string v2, "VideoOutput.WaitUntilFirstFrameRenderedNotify"

    .line 26
    .line 27
    invoke-virtual {p3, v2, v1}, Lio/flutter/plugin/common/MethodChannel;->invokeMethod(Ljava/lang/String;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    const-string p3, "media_kit"

    .line 31
    .line 32
    sget-object v1, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 33
    .line 34
    const-string v2, "VideoOutput.WaitUntilFirstFrameRenderedNotify = %d"

    .line 35
    .line 36
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    new-array p2, p4, [Ljava/lang/Object;

    .line 41
    .line 42
    const/4 p4, 0x0

    .line 43
    aput-object p1, p2, p4

    .line 44
    .line 45
    invoke-static {v1, v2, p2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-static {p3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 50
    .line 51
    .line 52
    goto :goto_0

    .line 53
    :catchall_0
    move-exception p1

    .line 54
    goto :goto_2

    .line 55
    :cond_0
    :goto_0
    const/4 p1, 0x0

    .line 56
    :goto_1
    if-nez p1, :cond_1

    .line 57
    .line 58
    invoke-virtual {p0}, Lw0/e;->f()Lio/flutter/embedding/engine/FlutterJNI;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    iget-wide p2, p0, Lw0/e;->a:J

    .line 63
    .line 64
    invoke-virtual {p1, p2, p3}, Lio/flutter/embedding/engine/FlutterJNI;->markTextureFrameAvailable(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :goto_2
    :try_start_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 69
    .line 70
    .line 71
    :cond_1
    monitor-exit v0

    .line 72
    return-void

    .line 73
    :catchall_1
    move-exception p1

    .line 74
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 75
    throw p1
.end method

.method public i(II)V
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p0, Lw0/e;->d:Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;

    .line 2
    .line 3
    invoke-interface {v0}, Lio/flutter/view/TextureRegistry$SurfaceTextureEntry;->surfaceTexture()Landroid/graphics/SurfaceTexture;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0, p1, p2}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 8
    .line 9
    .line 10
    goto :goto_0

    .line 11
    :catchall_0
    move-exception p1

    .line 12
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 13
    .line 14
    .line 15
    :goto_0
    return-void
.end method
