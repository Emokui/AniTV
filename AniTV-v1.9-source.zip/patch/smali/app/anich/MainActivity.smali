.class public final Lapp/anich/MainActivity;
.super Lg1/e;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lg1/e;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0
    invoke-super {p0, p1}, Lg1/e;->onCreate(Landroid/os/Bundle;)V
    invoke-static {p0}, Lapp/anich/TvPlayerBridge;->initialize(Landroid/app/Activity;)V
    return-void
.end method
.method protected onDestroy()V
    .locals 0
    invoke-static {p0}, Lapp/anich/TvPlayerBridge;->release(Landroid/app/Activity;)V
    invoke-super {p0}, Lg1/e;->onDestroy()V
    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 1
    invoke-static {p1}, Lapp/anich/TvPlayerBridge;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    move-result v0
    if-eqz v0, :parent
    const/4 v0, 0x1
    return v0
    :parent
    invoke-super {p0, p1}, Lg1/e;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    move-result v0
    return v0
.end method

.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 1
    invoke-static {p1}, Lapp/anich/UiProfile;->wrap(Landroid/content/Context;)Landroid/content/Context;
    move-result-object v0
    invoke-super {p0, v0}, Lg1/e;->attachBaseContext(Landroid/content/Context;)V
    return-void
.end method

.method protected onStop()V
    .locals 1
    invoke-static {}, Lapp/anich/TvPlayerBridge;->resetExit()V
    invoke-super {p0}, Lg1/e;->onStop()V
    const/16 v0, 0x14
    invoke-virtual {p0, v0}, Landroid/app/Activity;->onTrimMemory(I)V
    return-void
.end method

.method public finish()V
    .locals 1
    invoke-static {p0}, Lapp/anich/TvPlayerBridge;->allowFinish(Landroid/app/Activity;)Z
    move-result v0
    if-eqz v0, :done
    invoke-super {p0}, Lg1/e;->finish()V
    :done
    return-void
.end method
