package app.anich;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

// Reads the existing Flutter sidebar state; no accessibility service or permission.
final class PanelState {
    private static Object field(Object object, String name) throws Exception {
        Field field = object.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(object);
    }
    private static View flutterView(View view) {
        if (view.getClass().getName().equals("io.flutter.embedding.android.FlutterView")) return view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)view;
            for (int i = 0; i < group.getChildCount(); ++i) {
                View found = flutterView(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }
    static void enable(Activity activity) {
        try {
            View view = flutterView(activity.getWindow().getDecorView());
            if (view == null) return;
            Object bridge = field(view, "accessibilityBridge");
            if (bridge == null) return;
            Object channel = field(bridge, "accessibilityChannel");
            Object handler = field(bridge, "accessibilityMessageHandler");
            for (Method method : channel.getClass().getMethods()) {
                if (method.getName().equals("setAccessibilityMessageHandler")) {
                    method.invoke(channel, handler); break;
                }
            }
            channel.getClass().getMethod("onAndroidAccessibilityEnabled").invoke(channel);
        } catch (Exception error) { android.util.Log.w("AniTVNative", "sidebar state unavailable", error); }
    }
    static void disable(Activity activity) {
        try {
            android.view.accessibility.AccessibilityManager manager = (android.view.accessibility.AccessibilityManager)
                    activity.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE);
            if (manager != null && manager.isEnabled()) return;
            View view = flutterView(activity.getWindow().getDecorView());
            if (view == null) return;
            Object bridge = field(view, "accessibilityBridge");
            if (bridge == null) return;
            Object channel = field(bridge, "accessibilityChannel");
            channel.getClass().getMethod("onAndroidAccessibilityDisabled").invoke(channel);
        } catch (Exception ignored) { }
    }
    static Boolean isOpen(Activity activity, String heading) {
        try {
            View view = flutterView(activity.getWindow().getDecorView());
            if (view == null) return null;
            Object bridge = field(view, "accessibilityBridge");
            Map<?, ?> nodes = (Map<?, ?>)field(bridge, "flutterSemanticsTree");
            if (nodes.isEmpty()) return null;
            for (Object node : nodes.values()) {
                if (heading.equals(field(node, "label"))) return true;
            }
            return false;
        } catch (Exception error) { return null; }
    }
    static final class IndexFocus {
        final int focusedId;
        final boolean inGrid, inFilters;
        IndexFocus(int id, boolean grid, boolean filters) { focusedId=id; inGrid=grid; inFilters=filters; }
    }
    private static Object focusParent(Object node) throws Exception {
        for (int i=0; node != null && i<24; ++i, node=field(node,"parent")) {
            if (((Integer)field(node,"flags") & (1<<21)) != 0) return node;
        }
        return null;
    }
    private static boolean descendant(Object node, Object parent) throws Exception {
        for (int i=0; node != null && i<64; ++i, node=field(node,"parent")) if (node==parent) return true;
        return false;
    }
    static IndexFocus indexFocus(Activity activity) {
        try {
            View view=flutterView(activity.getWindow().getDecorView());
            if (view==null) return null;
            Object bridge=field(view,"accessibilityBridge");
            Map<?,?> nodes=(Map<?,?>)field(bridge,"flutterSemanticsTree");
            Object reset=null, focused=null;
            boolean index=false;
            for (Object node:nodes.values()) {
                String label=(String)field(node,"label");
                if ("重置".equals(label)) reset=node;
                if ("索引".equals(label)) index=true;
                if (((Integer)field(node,"flags") & 32)!=0) focused=node;
            }
            if (!index || reset==null || focused==null) return null;
            Object resetFocus=focusParent(reset);
            if (resetFocus==null) return null;
            Object filters=field(resetFocus,"parent");
            boolean inFilters=descendant(focused,filters);
            android.graphics.Rect focusRect=(android.graphics.Rect)field(focused,"globalRect");
            android.graphics.Rect barRect=(android.graphics.Rect)field(filters,"globalRect");
            boolean grid=!inFilters && focusRect!=null && barRect!=null && focusRect.centerY()>barRect.bottom;
            return new IndexFocus((Integer)field(focused,"id"),grid,inFilters);
        } catch (Exception ignored) { return null; }
    }
}
