package app.anich;
import android.media.MediaDataSource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;

/** Seekable MP4 input. MediaDataSource selects Android NuPlayer, not HSPlayer. */
final class HttpRangeSource extends MediaDataSource {
    private static final int BLOCK = 512 * 1024;
    private final String url;
    private final Map<String, String> headers;
    private final LinkedHashMap<Long, byte[]> blocks = new LinkedHashMap<Long, byte[]>(8, .75f, true) {
        protected boolean removeEldestEntry(Map.Entry<Long, byte[]> entry) { return size() > 4; }
    };
    private volatile long total = -1;
    private volatile boolean closed;
    private volatile HttpURLConnection active;
    HttpRangeSource(String url, Map<String, String> headers) {
        this.url = url; this.headers = new java.util.HashMap<>(headers);
    }
    void probe() throws IOException { block(0); }
    private synchronized byte[] block(long start) throws IOException {
        if (closed) throw new IOException("closed");
        byte[] found = blocks.get(start);
        if (found != null) return found;
        if (total >= 0 && start >= total) return new byte[0];
        HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
        active = connection;
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(15000);
        connection.setInstanceFollowRedirects(true);
        for (Map.Entry<String,String> header : headers.entrySet()) connection.setRequestProperty(header.getKey(), header.getValue());
        connection.setRequestProperty("Accept-Encoding", "identity");
        connection.setRequestProperty("Range", "bytes=" + start + "-" + (start + BLOCK - 1));
        InputStream input = null;
        try {
            int code = connection.getResponseCode();
            if (code != 200 && code != 206) throw new IOException("HTTP " + code);
            String range = connection.getHeaderField("Content-Range");
            if (range != null && range.lastIndexOf('/') >= 0) {
                try { total = Long.parseLong(range.substring(range.lastIndexOf('/') + 1)); } catch (NumberFormatException ignored) { }
            } else if (code == 200) {
                long length = connection.getContentLengthLong();
                if (length >= 0) total = length;
            }
            input = connection.getInputStream();
            if (code == 200 && start > 0) {
                long left = start;
                byte[] skip = new byte[16384];
                while (left > 0 && !closed) {
                    int n = input.read(skip, 0, (int)Math.min(left, skip.length));
                    if (n < 0) return new byte[0];
                    left -= n;
                }
            }
            int wanted = total >= 0 ? (int)Math.min((long)BLOCK, total - start) : BLOCK;
            ByteArrayOutputStream data = new ByteArrayOutputStream(wanted);
            byte[] buffer = new byte[32768];
            while (data.size() < wanted && !closed) {
                int n = input.read(buffer, 0, Math.min(buffer.length, wanted - data.size()));
                if (n < 0) break;
                data.write(buffer, 0, n);
            }
            if (closed) throw new IOException("closed");
            byte[] result = data.toByteArray();
            blocks.put(start, result);
            return result;
        } finally {
            if (input != null) try { input.close(); } catch (IOException ignored) { }
            connection.disconnect();
            if (active == connection) active = null;
        }
    }
    @Override public synchronized int readAt(long position, byte[] target, int offset, int size) throws IOException {
        if (closed) throw new IOException("closed");
        if (size == 0) return 0;
        if (position < 0 || (total >= 0 && position >= total)) return -1;
        long start = position / BLOCK * BLOCK;
        byte[] data = block(start);
        int inside = (int)(position - start);
        if (inside >= data.length) return -1;
        int count = Math.min(size, data.length - inside);
        System.arraycopy(data, inside, target, offset, count);
        return count;
    }
    @Override public long getSize() { return total; }
    @Override public void close() {
        closed = true;
        HttpURLConnection connection = active;
        if (connection != null) connection.disconnect();
    }
}
