package app.anich;

import android.content.Context;
import android.content.res.Configuration;

public final class UiProfile {
    public static Context wrap(Context base) {
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.densityDpi = Math.min(config.densityDpi, 240);
        config.fontScale = Math.min(config.fontScale, 0.75f);
        return base.createConfigurationContext(config);
    }
}
