package app.anich;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class TvPlayerBridge {
    private static final String TAG = "AniTVNative";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static long exitBackAt;
    private static boolean rootCheckPending, passingFinish;
    private static int rootGeneration, rootBackRequests;
    private static void cancelRootCheck() {
        rootGeneration++;
        if (rootCheckPending && owner != null) PanelState.disable(owner);
        rootCheckPending=false;
        rootBackRequests=0;
    }
    private static android.widget.Toast exitToast;
    public static void resetExit() {
        cancelRootCheck();
        exitBackAt = 0;
        if (exitToast != null) { exitToast.cancel(); exitToast = null; }
    }
    // Flutter requests Activity.finish only after its root route handles Back.
    public static boolean allowFinish(Activity activity) {
        if (passingFinish) return true;
        rootBackRequests++;
        if (rootCheckPending) return false;
        rootCheckPending=true;
        final int generation=++rootGeneration;
        PanelState.enable(activity);
        MAIN.postDelayed(() -> {
            if (generation!=rootGeneration || owner!=activity || activity.isFinishing()) return;
            PanelState.IndexFocus focus=PanelState.indexFocus(activity);
            if (focus!=null && focus.inGrid) {
                exitBackAt=0;
                if (exitToast!=null) { exitToast.cancel(); exitToast=null; }
                returnToIndexFilters(activity,generation,0,-1,0);
            } else finishRootCheck(activity,generation,false);
        },250);
        return false;
    }
    private static void returnToIndexFilters(Activity activity,int generation,int steps,int previousId,long deadline) {
        if (generation!=rootGeneration || owner!=activity || activity.isFinishing()) return;
        PanelState.IndexFocus focus=PanelState.indexFocus(activity);
        if (focus!=null && focus.inFilters) {
            Log.i(TAG,"index Back returned to filters after "+steps+" rows");
            finishRootCheck(activity,generation,true);
            return;
        }
        if (focus==null || !focus.inGrid || steps>=120) {
            finishRootCheck(activity,generation,true);
            return;
        }
        if (focus.focusedId==previousId) {
            if (SystemClock.uptimeMillis()>=deadline) {
                finishRootCheck(activity,generation,true);
            } else MAIN.postDelayed(() -> returnToIndexFilters(activity,generation,steps,previousId,deadline),40);
            return;
        }
        int id=focus.focusedId;
        long until=SystemClock.uptimeMillis()+1000;
        parentKey(activity,KeyEvent.KEYCODE_DPAD_UP);
        MAIN.postDelayed(() -> returnToIndexFilters(activity,generation,steps+1,id,until),40);
    }
    private static void finishRootCheck(Activity activity,int generation,boolean returned) {
        if (generation!=rootGeneration) return;
        int requests=rootBackRequests;
        cancelRootCheck();
        if (returned) { exitBackAt=0; return; }
        long now=SystemClock.uptimeMillis();
        if (requests>1 || (exitBackAt!=0 && now-exitBackAt<=2000)) {
            resetExit();
            passingFinish=true;
            try { activity.finish(); } finally { passingFinish=false; }
        } else {
            exitBackAt=now;
            if (exitToast!=null) exitToast.cancel();
            exitToast=android.widget.Toast.makeText(activity,"再按一次返回退出",android.widget.Toast.LENGTH_SHORT);
            exitToast.show();
        }
    }
    private static Activity owner;
    private static Player current;
    private static Player selectionReturn;
    private static boolean parentDispatch;
    private static long parentKeyTime;
    private static int parentKeyCode;

    private static void parentKey(Activity activity, int key) {
        parentDispatch = true;
        long now = SystemClock.uptimeMillis();
        parentKeyTime = now;
        parentKeyCode = key;
        try {
            activity.dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, key, 0));
            activity.dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, key, 0));
        } finally { parentDispatch = false; }
    }
    private static void parentSourceMenu(Activity activity) {
        long now = SystemClock.uptimeMillis();
        parentKeyTime = now;
        parentKeyCode = KeyEvent.KEYCODE_DPAD_UP;
        parentDispatch = true;
        try { activity.dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_UP, 0)); }
        finally { parentDispatch = false; }
        MAIN.postDelayed(() -> {
            if (owner != activity || activity.isFinishing()) return;
            parentDispatch = true;
            try { activity.dispatchKeyEvent(new KeyEvent(now, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_UP, 0)); }
            finally { parentDispatch = false; }
        }, 1100);
    }
    public static boolean dispatchKeyEvent(KeyEvent event) {
        if (!parentDispatch && !(event.getDownTime()==parentKeyTime && event.getKeyCode()==parentKeyCode) &&
                event.getAction()==KeyEvent.ACTION_DOWN && event.getKeyCode()!=KeyEvent.KEYCODE_BACK) {
            exitBackAt=0;
            if (rootCheckPending) cancelRootCheck();
        }
        if (parentDispatch || selectionReturn == null ||
                (event.getDownTime() == parentKeyTime && event.getKeyCode() == parentKeyCode)) return false;
        int key = event.getKeyCode();
        if (key == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) returnFromSelection();
            return true;
        }
        if ((key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) &&
                event.getAction() == KeyEvent.ACTION_UP) {
            final Player saved = selectionReturn;
            MAIN.postDelayed(() -> {
                if (selectionReturn != saved || owner != saved.activity) return;
                Boolean open = PanelState.isOpen(saved.activity, saved.navigation == KeyEvent.KEYCODE_MENU ? "切换线路" : "选集");
                Log.i(TAG, "selection confirmation; sidebar open=" + open);
                if (Boolean.TRUE.equals(open)) returnFromSelection();
            }, 600);
        }
        return false;
    }
    private static void returnFromSelection() {
        Player saved = selectionReturn;
        if (saved == null || owner != saved.activity || owner.isFinishing()) return;
        selectionReturn = null;
        Boolean panelOpen = PanelState.isOpen(saved.activity, saved.navigation == KeyEvent.KEYCODE_MENU ? "切换线路" : "选集");
        if (!Boolean.FALSE.equals(panelOpen)) parentKey(saved.activity, KeyEvent.KEYCODE_BACK);
        current = new Player(saved.activity, saved.url, saved.title, saved.rawHeaders, saved.token);
        current.resumePosition = saved.resumePosition;
        current.resumePlaying = saved.resumePlaying;
        current.show();
        PanelState.disable(saved.activity);
        Log.i(TAG, "returned from episode selection at " + saved.resumePosition);
    }
    private static native void nativeInitialize();
    private static native void nativeSavePosition(long token, int position);

    public static void initialize(Activity activity) {
        resetExit();
        owner = activity;
        System.loadLibrary("anichtvbridge");
        nativeInitialize();
    }
    public static void release(Activity activity) {
        if (owner != activity) return;
        resetExit();
        selectionReturn = null;
        if (current != null) current.close(0);
        owner = null;
    }
    public static void open(String url, String title, String rawHeaders, long token) {
        MAIN.post(() -> {
            Activity activity = owner;
            if (activity == null || activity.isFinishing()) return;
            PanelState.disable(activity);
            Player sourceReturn = selectionReturn != null && selectionReturn.navigation == KeyEvent.KEYCODE_MENU ? selectionReturn : null;
            selectionReturn = null;
            if (current != null) current.close(0);
            current = new Player(activity, url, title, rawHeaders, token);
            if (sourceReturn != null) {
                current.resumePosition = sourceReturn.resumePosition;
                current.resumePlaying = sourceReturn.resumePlaying;
                Log.i(TAG, "source changed; restoring " + sourceReturn.resumePosition);
            }
            current.show();
        });
    }

    private static final class Player extends Dialog implements SurfaceHolder.Callback {
        final Activity activity;
        final String url, title, rawHeaders;
        final long token;
        final Map<String, String> headers = new HashMap<>();
        final Handler timer = new Handler(Looper.getMainLooper());
        final FrameLayout frame;
        final SurfaceView surface;
        LinearLayout controls;
        final TextView heading, status, time;
        final ProgressBar loading;
        final SeekBar progress;
        final AudioManager audio;
        final AudioManager.OnAudioFocusChangeListener focus;
        MediaPlayer media;
        HttpRangeSource source;
        boolean prepared, closed, failed, finished;
        int navigation, bufferPercent, resumePosition;
        boolean resumePlaying = true;
        long lastSeek;

        Player(Activity activity, String url, String title, String rawHeaders, long token) {
            super(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            this.activity = activity;
            this.url = url;
            this.rawHeaders = rawHeaders;
            this.title = title == null || title.length() == 0 || title.length() > 80 ? "AniCh 电视播放器" : title;
            this.token = token;
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            Window window = getWindow();
            window.setBackgroundDrawable(new ColorDrawable(Color.BLACK));
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            frame = new FrameLayout(activity);
            frame.setBackgroundColor(Color.BLACK);
            surface = new SurfaceView(activity);
            surface.getHolder().addCallback(this);
            frame.addView(surface, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            loading = new ProgressBar(activity);
            frame.addView(loading, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER));
            status = label(20);
            status.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams message = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
            message.topMargin = dp(100);
            frame.addView(status, message);
            controls = new LinearLayout(activity);
            controls.setOrientation(LinearLayout.VERTICAL);
            controls.setPadding(dp(28), dp(16), dp(28), dp(18));
            controls.setBackgroundColor(0xCC101010);
            heading = label(21);
            heading.setText(this.title);
            heading.setMaxLines(2);
            controls.addView(heading);
            time = label(20);
            controls.addView(time);
            progress = new SeekBar(activity);
            progress.setFocusable(false);
            progress.setMax(1000);
            controls.addView(progress, new LinearLayout.LayoutParams(-1, dp(30)));
            TextView help = label(16);
            help.setText("确认：播放 / 暂停     ← / →：快退 / 快进 10 秒     ↑：选集     ↓ / 菜单：线路     返回：退出播放");
            controls.addView(help);
            frame.addView(controls, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
            setContentView(frame);
            setCancelable(false);
            audio = (AudioManager)activity.getSystemService(Context.AUDIO_SERVICE);
            focus = change -> {
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    if (prepared && !closed && media != null && media.isPlaying()) {
                        media.pause(); showControls();
                    }
                }
            };
            headers.put("User-Agent", "Mozilla/5.0 (Linux; Android 8.0; Android TV) AppleWebKit/537.36 Chrome/108.0 Safari/537.36");
            if (rawHeaders != null) for (String line : rawHeaders.split("\n")) {
                int colon = line.indexOf(':');
                if (colon > 0) headers.put(line.substring(0, colon).trim(), line.substring(colon + 1).trim());
            }
            setOnDismissListener(dialog -> {
                dispose();
                if (current == this) current = null;
                if (navigation != 0 && owner == activity && !activity.isFinishing()) {
                    int key = navigation;
                    MAIN.postDelayed(() -> {
                        if (owner != activity || activity.isFinishing()) return;
                        if (key == KeyEvent.KEYCODE_MENU) parentSourceMenu(activity);
                        else parentKey(activity, key);
                    }, 250);
                }
            });
            setOnKeyListener((dialog, key, event) -> {
                boolean handled = key == KeyEvent.KEYCODE_BACK || key == KeyEvent.KEYCODE_DPAD_UP ||
                    key == KeyEvent.KEYCODE_DPAD_DOWN || key == KeyEvent.KEYCODE_DPAD_LEFT ||
                    key == KeyEvent.KEYCODE_DPAD_RIGHT || key == KeyEvent.KEYCODE_DPAD_CENTER ||
                    key == KeyEvent.KEYCODE_ENTER || key == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                    key == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || key == KeyEvent.KEYCODE_MEDIA_REWIND ||
                    key == KeyEvent.KEYCODE_MEDIA_NEXT || key == KeyEvent.KEYCODE_MENU;
                if (!handled) return false;
                if (event.getAction() != KeyEvent.ACTION_DOWN) return true;
                if (key == KeyEvent.KEYCODE_BACK) close(KeyEvent.KEYCODE_BACK);
                else if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_MEDIA_NEXT) close(KeyEvent.KEYCODE_DPAD_UP);
                else if (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_MEDIA_REWIND) seek(-10000);
                else if (key == KeyEvent.KEYCODE_DPAD_RIGHT || key == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) seek(10000);
                else if (key == KeyEvent.KEYCODE_DPAD_DOWN || key == KeyEvent.KEYCODE_MENU) close(KeyEvent.KEYCODE_MENU);
                else if (event.getRepeatCount() == 0) toggle();
                return true;
            });
        }
        int dp(int value) { return (int)(value * activity.getResources().getDisplayMetrics().density + 0.5f); }
        TextView label(int size) {
            TextView text = new TextView(activity);
            text.setTextColor(Color.WHITE);
            text.setTextSize(size);
            text.setShadowLayer(2, 1, 1, Color.BLACK);
            return text;
        }
        @Override public void show() {
            super.show();
            getWindow().setLayout(-1, -1);
            audio.requestAudioFocus(focus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            showControls();
            timer.post(tick);
        }
        @Override public void surfaceCreated(SurfaceHolder holder) { prepare(holder); }
        @Override public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) { }
        @Override public void surfaceDestroyed(SurfaceHolder holder) { releaseMedia(); }
        void prepare(SurfaceHolder holder) {
            releaseMedia();
            if (closed || !holder.getSurface().isValid()) return;
            failed = false; finished = false; bufferPercent = 0;
            loading.setVisibility(View.VISIBLE);
            status.setText("正在打开视频…");
            media = new MediaPlayer();
            media.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build());
            media.setVolume(1.0f, 1.0f);
            media.setScreenOnWhilePlaying(true);
            media.setDisplay(holder);
            media.setOnPreparedListener(player -> {
                if (closed || media != player) return;
                prepared = true;
                // The Flutter browsing surface is covered by native video.
                // Let Flutter drop decoded poster and graphics caches, not live video.
                activity.onTrimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN);
                fit(player.getVideoWidth(), player.getVideoHeight());
                player.setVolume(1.0f, 1.0f);
                if (resumePosition > 0) {
                    final int position = resumePosition;
                    resumePosition = 0;
                    player.setOnSeekCompleteListener(seeked -> {
                        seeked.setOnSeekCompleteListener(null);
                        if (!closed && media == seeked && resumePlaying) seeked.start();
                        Log.i(TAG, "resumed position " + position);
                    });
                    player.seekTo(position);
                } else if (resumePlaying) player.start();
                status.setText("");
                Log.i(TAG, "prepared " + player.getVideoWidth() + "x" + player.getVideoHeight() + " duration=" + player.getDuration());
                showControls();
            });
            media.setOnVideoSizeChangedListener((player, w, h) -> fit(w, h));
            media.setOnBufferingUpdateListener((player, percent) -> bufferPercent = percent);
            media.setOnInfoListener((player, what, extra) -> {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START || what == MediaPlayer.MEDIA_INFO_BUFFERING_END) {
                    loading.setVisibility(View.GONE); status.setText("");
                    Log.i(TAG, what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START ? "first frame rendered" : "buffering ended");
                } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                    loading.setVisibility(View.VISIBLE); status.setText("正在缓冲…");
                }
                return false;
            });
            media.setOnCompletionListener(player -> {
                finished = true;
                loading.setVisibility(View.GONE);
                status.setText("播放结束：确认键重播，↑ 选择下一集");
                showControls();
            });
            media.setOnErrorListener((player, what, extra) -> {
                failed = true; prepared = false;
                loading.setVisibility(View.GONE);
                status.setText("播放失败（" + what + "/" + extra + "）\n确认键重试，↑ 换集，↓ 切换线路");
                Log.e(TAG, "MediaPlayer error " + what + "/" + extra);
                showControls(); return true;
            });
            final MediaPlayer target = media;
            if (url.toLowerCase(Locale.ROOT).contains(".m3u8")) {
                try { target.setDataSource(activity, Uri.parse(url), headers); target.prepareAsync(); }
                catch (Exception error) { openError(error); }
            } else {
                final HttpRangeSource data = new HttpRangeSource(url, headers);
                source = data;
                new Thread(() -> {
                    try {
                        data.probe();
                        MAIN.post(() -> {
                            if (closed || media != target) { data.close(); return; }
                            try { target.setDataSource(data); target.prepareAsync(); }
                            catch (Exception error) { openError(error); }
                        });
                    } catch (Exception error) {
                        MAIN.post(() -> { if (!closed && media == target) openError(error); });
                    }
                }, "AniTV-HTTP").start();
            }
        }
        void openError(Exception error) {
            failed = true;
            loading.setVisibility(View.GONE);
            status.setText("无法打开视频，确认键重试\n" + error.getClass().getSimpleName());
            Log.e(TAG, "prepare failed", error);
        }

        void fit(int w, int h) {
            if (w <= 0 || h <= 0 || closed) return;
            frame.post(() -> {
                if (closed) return;
                int fw = frame.getWidth(), fh = frame.getHeight();
                if (fw <= 0 || fh <= 0) return;
                float scale = Math.min((float)fw / w, (float)fh / h);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(w * scale), Math.round(h * scale), Gravity.CENTER);
                surface.setLayoutParams(lp);
            });
        }
        void toggle() {
            if (failed) { prepare(surface.getHolder()); return; }
            if (!prepared || media == null || closed) return;
            if (finished) { media.seekTo(0); finished = false; status.setText(""); media.start(); }
            else if (media.isPlaying()) media.pause(); else media.start();
            showControls();
        }
        void seek(int delta) {
            if (!prepared || media == null || closed) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastSeek < 250) return;
            lastSeek = now;
            int duration = media.getDuration();
            if (duration <= 0) return;
            int position = Math.max(0, Math.min(duration - 1000, media.getCurrentPosition() + delta));
            if (Build.VERSION.SDK_INT >= 26) media.seekTo((long)position, MediaPlayer.SEEK_CLOSEST_SYNC);
            else media.seekTo(position);
            Log.i(TAG, "seek " + position);
            showControls();
        }
        void showControls() {
            controls.setVisibility(View.VISIBLE);
            update();
            timer.removeCallbacks(hide);
            timer.postDelayed(hide, 4000);
        }
        final Runnable hide = () -> {
            if (prepared && media != null && !closed && media.isPlaying() && !finished) controls.setVisibility(View.GONE);
        };
        final Runnable tick = new Runnable() {
            @Override public void run() {
                if (closed) return;
                if (controls.getVisibility() == View.VISIBLE) update();
                timer.postDelayed(this, 1000);
            }
        };
        void update() {
            if (!prepared || media == null || closed) return;
            try {
                int position = media.getCurrentPosition(), duration = media.getDuration();
                time.setText((media.isPlaying() ? "播放中   " : "已暂停   ") + clock(position) + " / " + clock(duration));
                if (duration > 0) progress.setProgress((int)((long)position * 1000 / duration));
                progress.setSecondaryProgress(bufferPercent * 10);
            } catch (IllegalStateException ignored) { }
        }
        static String clock(int ms) {
            if (ms < 0) return "--:--";
            int sec = ms / 1000;
            return sec >= 3600 ? String.format(Locale.ROOT, "%d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60)
                : String.format(Locale.ROOT, "%02d:%02d", sec / 60, sec % 60);
        }
        void close(int navigation) {
            if (closed) return;
            this.navigation = navigation;
            if (prepared && media != null) try {
                int position = media.getCurrentPosition(), duration = media.getDuration();
                if (duration > 1000) position = Math.min(position, duration - 1000);
                resumePosition = Math.max(position, 0);
                resumePlaying = media.isPlaying();
                nativeSavePosition(token, resumePosition);
            } catch (Throwable ignored) { }
            if (navigation == KeyEvent.KEYCODE_MENU) {
                PanelState.enable(activity);
                selectionReturn = this;
                Log.i(TAG, "source selection saved at " + resumePosition);
            }
            if (navigation == KeyEvent.KEYCODE_DPAD_UP) {
                PanelState.enable(activity);
                selectionReturn = this;
                Log.i(TAG, "episode selection saved at " + resumePosition);
            }
            dismiss();
        }
        void releaseMedia() {
            prepared = false;
            HttpRangeSource oldSource = source;
            source = null;
            if (oldSource != null) oldSource.close();
            MediaPlayer old = media;
            media = null;
            if (old != null) {
                old.setOnPreparedListener(null); old.setOnErrorListener(null); old.setOnCompletionListener(null);
                old.setOnInfoListener(null); old.setOnVideoSizeChangedListener(null); old.setOnBufferingUpdateListener(null);
                old.release();
                Log.i(TAG, "released");
            }
        }
        void dispose() {
            if (closed) return;
            closed = true;
            timer.removeCallbacksAndMessages(null);
            releaseMedia();
            audio.abandonAudioFocus(focus);
        }
    }
}
