#include <jni.h>
extern int pthread_mutex_lock(void *);
extern int pthread_mutex_unlock(void *);
extern int org_set_property(void *, const char *, int, void *);
static JavaVM *vm;
static jclass bridge_class, string_class;
static jmethodID open_method, string_ctor;
static void *player_context;
static unsigned generation;
/* Bionic's static zero-initialized mutex; enough storage for either ABI. */
static int context_lock[16];

JNIEXPORT void JNICALL Java_app_anich_TvPlayerBridge_nativeInitialize(JNIEnv *env, jclass type) {
    (*env)->GetJavaVM(env, &vm);
    if (!bridge_class) {
        bridge_class = (*env)->NewGlobalRef(env, type);
        open_method = (*env)->GetStaticMethodID(env, type, "open", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V");
        jclass str = (*env)->FindClass(env, "java/lang/String");
        string_class = (*env)->NewGlobalRef(env, str);
        string_ctor = (*env)->GetMethodID(env, str, "<init>", "([BLjava/lang/String;)V");
        (*env)->DeleteLocalRef(env, str);
    }
}
static jstring utf8(JNIEnv *env, const char *value) {
    int len = 0;
    if (value) while (value[len] && len < 32768) ++len;
    jbyteArray bytes = (*env)->NewByteArray(env, len);
    if (!bytes) return (void *)0;
    if (len) (*env)->SetByteArrayRegion(env, bytes, 0, len, (const jbyte *)value);
    jstring encoding = (*env)->NewStringUTF(env, "UTF-8");
    jstring result = (jstring)(*env)->NewObject(env, string_class, string_ctor, bytes, encoding);
    (*env)->DeleteLocalRef(env, bytes);
    (*env)->DeleteLocalRef(env, encoding);
    return result;
}
int tvplayer_open(void *ctx, const char *url, const char *title, const char *headers) {
    if (!vm || !bridge_class || !open_method) return -1;
    pthread_mutex_lock(context_lock);
    player_context = ctx;
    unsigned token = ++generation;
    pthread_mutex_unlock(context_lock);
    JNIEnv *env = (void *)0;
    int attached = 0;
    if ((*vm)->GetEnv(vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) {
        if ((*vm)->AttachCurrentThread(vm, (void **)&env, (void *)0) != JNI_OK) return -1;
        attached = 1;
    }
    jstring jurl = utf8(env, url), jtitle = utf8(env, title), jheaders = utf8(env, headers);
    if (jurl && jtitle && jheaders)
        (*env)->CallStaticVoidMethod(env, bridge_class, open_method, jurl, jtitle, jheaders, (jlong)token);
    if ((*env)->ExceptionCheck(env)) {
        (*env)->ExceptionDescribe(env);
        (*env)->ExceptionClear(env);
    }
    if (jurl) (*env)->DeleteLocalRef(env, jurl);
    if (jtitle) (*env)->DeleteLocalRef(env, jtitle);
    if (jheaders) (*env)->DeleteLocalRef(env, jheaders);
    if (attached) (*vm)->DetachCurrentThread(vm);
    return 0;
}
void tvplayer_forget(void *ctx) {
    pthread_mutex_lock(context_lock);
    if (player_context == ctx) { player_context = (void *)0; ++generation; }
    pthread_mutex_unlock(context_lock);
}
JNIEXPORT void JNICALL Java_app_anich_TvPlayerBridge_nativeSavePosition(JNIEnv *env, jclass type, jlong token, jint position) {
    pthread_mutex_lock(context_lock);
    if (player_context && (unsigned)token == generation) {
        double seconds = position / 1000.0;
        org_set_property(player_context, "time-pos", 5, &seconds);
    }
    pthread_mutex_unlock(context_lock);
}
