#!/usr/bin/env python3
"""Repackage the exact official ARMv7 APK, preserving its original DEX/assets."""
import argparse
import hashlib
import struct
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

EXPECTED_SHA256 = 'f35f1ca9755e0a13486e8c030139ef3a75a609abd061419c19a5a362b0b45069'
EXPORTS = ('mpv_set_property', 'mpv_set_property_string', 'mpv_set_property_async',
           'mpv_set_option', 'mpv_set_option_string', 'mpv_command',
           'mpv_command_async', 'mpv_command_ret', 'mpv_wait_event',
           'mpv_destroy', 'mpv_terminate_destroy')


def patch_core(data):
    data = bytearray(data)
    h = struct.unpack_from('<16sHHIIIIIHHHHHH', data)
    assert h[0][:7] == b'\x7fELF\x01\x01\x01' and h[2] == 40, 'Expected ARM ELF32'
    sections = [struct.unpack_from('<IIIIIIIIII', data, h[6] + i * h[11])
                for i in range(h[12])]
    ns = sections[h[13]]
    names = data[ns[4]:ns[4] + ns[5]]
    by_name = {bytes(names[s[0]:]).split(b'\0')[0].decode(): s for s in sections}
    sym = by_name['.dynsym']
    st = sections[sym[6]]
    strings = bytes(data[st[4]:st[4] + st[5]])
    for name in (*EXPORTS, 'libmpv.so'):
        old = name.encode() + b'\0'
        new = ('org' + name[3:] if name != 'libmpv.so' else 'liborg.so').encode() + b'\0'
        assert strings.count(old) == 1, name
        pos = st[4] + strings.index(old)
        data[pos:pos + len(old)] = new
    symbol_names = []
    for pos in range(sym[4], sym[4] + sym[5], sym[9]):
        offset = struct.unpack_from('<I', data, pos)[0]
        symbol_names.append(bytes(data[st[4] + offset:st[4] + st[5]]).split(b'\0')[0])

    # A single bucket preserves symbol indexes and relocation targets while
    # supporting renamed symbols without reordering the dynamic symbol table.
    def gnu_hash(value):
        result = 5381
        for c in value:
            result = (result * 33 + c) & 0xffffffff
        return result

    if '.gnu.hash' in by_name:
        sec = by_name['.gnu.hash']
        first = struct.unpack_from('<IIII', data, sec[4])[1]
        table = bytearray(struct.pack('<IIIIII', 1, first, 1, 5, 0xffffffff, first))
        for i in range(first, len(symbol_names)):
            table += struct.pack('<I', (gnu_hash(symbol_names[i]) & ~1)
                                 | (i == len(symbol_names) - 1))
        assert len(table) <= sec[5]
        data[sec[4]:sec[4] + sec[5]] = table + bytes(sec[5] - len(table))
    if '.hash' in by_name:
        sec = by_name['.hash']
        count = len(symbol_names)
        table = struct.pack('<III', 1, count, 1) + b''.join(
            struct.pack('<I', i + 1 if 0 < i < count - 1 else 0) for i in range(count))
        assert len(table) <= sec[5]
        data[sec[4]:sec[4] + sec[5]] = table + bytes(sec[5] - len(table))
    return bytes(data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('original', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--shim', type=Path)
    parser.add_argument('--dex', type=Path)
    parser.add_argument('--bridge', type=Path)
    parser.add_argument('--app', type=Path)
    parser.add_argument('--branding', type=Path)
    args = parser.parse_args()
    assert hashlib.sha256(args.original.read_bytes()).hexdigest() == EXPECTED_SHA256
    with ZipFile(args.original) as source:
        core = patch_core(source.read('lib/armeabi-v7a/libmpv.so'))
        if not args.shim:
            args.output.write_bytes(core)
            return
        manifest = source.read('AndroidManifest.xml')
        for encoding in ('utf-8', 'utf-16-le'):
            manifest = manifest.replace('app.anich'.encode(encoding), 'tvx.anich'.encode(encoding))
            manifest = manifest.replace('tvx.anich.MainActivity'.encode(encoding),
                                        'app.anich.MainActivity'.encode(encoding))
            manifest = manifest.replace('AniCh'.encode(encoding), 'AniTV'.encode(encoding))
        manifest = bytearray(manifest)
        mapping = []
        pos = 8
        while pos < len(manifest):
            kind, header, size = struct.unpack_from('<HHI', manifest, pos)
            assert size >= header and size > 0
            if kind == 0x0180:
                mapping = list(struct.unpack_from('<' + 'I' * ((size-header)//4), manifest, pos+header))
            if kind == 0x0102:
                attr_start, attr_size, count = struct.unpack_from('<HHH', manifest, pos+24)
                for i in range(count):
                    attr = pos+16+attr_start+i*attr_size
                    name = struct.unpack_from('<I',manifest,attr+4)[0]
                    resource = mapping[name] if name < len(mapping) else 0
                    value = {0x0101020c:26, 0x0101021b:1002}.get(resource)
                    if value is not None:
                        struct.pack_into('<I',manifest,attr+8,0xffffffff)
                        manifest[attr+15] = 0x10
                        struct.pack_into('<I',manifest,attr+16,value)
                    if args.branding and resource == 0x010103f2:
                        # Separate rectangular TV banner from the square launcher icon.
                        assert struct.unpack_from('<I',manifest,attr+16)[0] == 0x7f0d0000
                        struct.pack_into('<I',manifest,attr+16,0x7f070091)
            pos += size
        manifest = bytes(manifest)
        resources = source.read('resources.arsc').replace(
            'app.anich'.encode('utf-16-le'), 'tvx.anich'.encode('utf-16-le'))
        replacements = {'AndroidManifest.xml': manifest, 'resources.arsc': resources,
                        'lib/armeabi-v7a/libmpv.so': args.shim.read_bytes()}
        if args.branding:
            # Android 8 TV launchers need a real bitmap, including the anydpi-v26
            # resource. Preserve resource IDs and replace only their file values.
            assert resources.count(b'res/BW.xml') == 1
            replacements['resources.arsc'] = resources.replace(b'res/BW.xml', b'res/BW.png')
            for path, size in [('res/9w.png',48), ('res/yn.png',72),
                               ('res/FS.png',96), ('res/RJ.png',144), ('res/o-.png',192)]:
                replacements[path] = (args.branding / ('icon-%d.png' % size)).read_bytes()
            # The old adaptive foreground is unused after replacing BW.xml.
            # Reuse that resource for the banner without reallocating any IDs.
            for path, width in [('res/bB.png',320), ('res/yi.png',480),
                                ('res/tP.png',640), ('res/BM.png',960), ('res/CH.png',1280)]:
                replacements[path] = (args.branding / ('banner-%d.png' % width)).read_bytes()
        if args.app:
            replacements['lib/armeabi-v7a/libapp.so'] = args.app.read_bytes()
        if args.dex:
            replacements['classes.dex'] = args.dex.read_bytes()
        with ZipFile(args.output, 'w') as dest:
            for entry in source.infolist():
                if args.branding and entry.filename == 'res/BW.xml':
                    continue
                upper = entry.filename.upper()
                if upper == 'META-INF/MANIFEST.MF' or (upper.startswith('META-INF/')
                        and upper.endswith(('.RSA', '.DSA', '.EC', '.SF'))):
                    continue
                dest.writestr(entry, replacements.get(entry.filename, source.read(entry)))
            if args.branding:
                entry = ZipInfo('res/BW.png', (2026, 10, 25, 0, 0, 0))
                entry.compress_type = ZIP_DEFLATED
                dest.writestr(entry, (args.branding / 'icon-512.png').read_bytes())
            entry = ZipInfo('lib/armeabi-v7a/liborg.so', (2026, 10, 25, 0, 0, 0))
            entry.compress_type = ZIP_DEFLATED
            dest.writestr(entry, core)
            if args.bridge:
                entry = ZipInfo('lib/armeabi-v7a/libanichtvbridge.so', (2026, 10, 25, 0, 0, 0))
                entry.compress_type = ZIP_DEFLATED
                dest.writestr(entry, args.bridge.read_bytes())
    print(args.output)


if __name__ == '__main__':
    main()
