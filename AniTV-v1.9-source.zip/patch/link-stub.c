void *dlopen(const char *name, int flags) { return (void *)0; }
void *dlsym(void *handle, const char *name) { return (void *)0; }
int dlclose(void *handle) { return 0; }
int pthread_mutex_lock(void *mutex) { return 0; }
int pthread_mutex_unlock(void *mutex) { return 0; }
