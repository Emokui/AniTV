#!/usr/bin/env python3
"""Simplify TV home/detail tabs and reduce fixed BoxShadow blur, preserving focus."""
import hashlib
from pathlib import Path
import struct
import argparse
from zipfile import ZipFile
parser=argparse.ArgumentParser(description='Exact AniCh 1.5.27 ARMv7 TV homepage and shadow patch')
parser.add_argument('original', type=Path)
parser.add_argument('output', type=Path)
args=parser.parse_args()
with ZipFile(args.original) as source:
 original=source.read('lib/armeabi-v7a/libapp.so')
assert hashlib.sha256(original).hexdigest() == 'e4310add234141a04790a8b40ad2d8339dcd8bcc794757493ffaf73197285091', 'Unexpected libapp.so input'
b=bytearray(original)
def w(o,old,new):
 assert struct.unpack_from('<I',b,o)[0]==old,(hex(o),hex(struct.unpack_from('<I',b,o)[0]),hex(old))
 struct.pack_into('<I',b,o,new)
def branch(o,t):return 0xea000000|(((t-o-8)//4)&0xffffff)
# TV home labels are an insertion-ordered map, independent from the mobile tabs.
w(0x546b64,0xe3a02014,0xe3a02010)
w(0x546b70,0xe280200b,branch(0x546b70,0x546bd0))
for o,old,new in [(0x546bd4,0x13,0xb),(0x546c0c,0x17,0xf),(0x546c38,0x1b,0x13),(0x546c70,0x1f,0x17),(0x546c9c,0x23,0x1b),(0x546cd4,0x27,0x1f),(0x546d00,0x2b,0x23),(0x546d38,0x2f,0x27)]:
 w(o, (0xe2812000 if o in [0x546bd4,0x546c38,0x546c9c,0x546d00] else 0xe2819000)|old,(0xe2812000 if o in [0x546bd4,0x546c38,0x546c9c,0x546d00] else 0xe2819000)|new)
# TV detail labels: Episodes, Characters, Recommendations.
w(0x7eb710,0xe3a0000a,0xe3a00006)
w(0x7eb748,0xe59cc7af,0xe59cc7b3)
w(0x7eb758,0xe59cc7b3,0xe59cc7bb)
w(0x7eb764,0xe285ca12,0xe285ca0e)
w(0x7eb768,0xe59cc7bb,0xe59cc3c3)
for at in range(0x7eb770,0x7eb790,4):
 w(at,struct.unpack_from('<I',original,at)[0],0xe1a00000)
w(0x7eb7a8,0xe3a0000a,0xe3a00006)
# Remap detail bodies from original indices 1, 2, 4 to 0, 1, 2.
# The existing initial index 0 now opens Episodes. Keep mobile detail untouched.
w(0x74da0c,0xe3510000,0xe3520000) # cmp r2, #0
w(0x74da10,0xba000002,branch(0x74da10,0x74da88)&0x0fffffff) # beq Episodes
w(0x74da14,0xca000057,0xe3520001) # cmp r2, #1
w(0x74da18,0xe3520002,branch(0x74da18,0x74db00)&0x0fffffff) # beq Characters
w(0x74da1c,0x8a000055,0xe3520002) # cmp r2, #2
w(0x74da20,0xe3510000,(branch(0x74da20,0x74dc78)&0x0fffffff)|0x10000000) # bne fallback
w(0x74da24,0xba000002,0xe51b3004) # restore context for Recommendations
w(0x74da28,0xca000034,branch(0x74da28,0x74dc0c))
# Let the first TV focus control claim an otherwise empty route focus scope.
# Flutter keeps existing route focus; this does not inject directional keys.
w(0x918bac,0xe59a003c,0xe59a0038)
# TV homepage index: fixed filter + Expanded independently scrolling grid.
# Reuse allocations/call sites and tagged stack roots in this same function.
def original_word(at,new): w(at,struct.unpack_from('<I',original,at)[0],new)
# Keep the filter rooted in the sliver backing array until the Column is ready.
for at,ins in [(0x979c2c,0xe51b0004),(0x979c3c,0xe51b000c),(0x979c48,0xe51b0024)]: original_word(at,ins)
original_word(0x979cf0,branch(0x979cf0,0xb63f54)|0x01000000)
for at,ins in [(0x979d04,0xe3a02004),(0x979d08,0xe583200f),
 (0x979d0c,0xe3a00000),(0x979d10,0xe5830013),
 (0x979d14,0xe2851901),(0x979d18,0xe59113bf),
 (0x979d1c,0xe5831017),(0x979d20,0xe59a1034),
 (0x979d34,0xe281300f),(0x979d58,0xe3a00004),
 (0x979d60,0xe1a00000),(0x979d64,0xe1a00000)]: original_word(at,ins)
original_word(0x979d68,branch(0x979d68,0xb63f48)|0x01000000)
column=[
  0xe1a03000, # mov r3,r0: Column
  0xe51b2004, # outer growable children
  0xe592100b, # backing array
  0xe591400f, # Expanded
  0xe5944007, # CustomScrollView
  0xe5944047, # slivers growable list
  0xe3a06004, # Smi length 2
  0xe5846007,
  0xe594400b, # backing slivers array
  0xe5944013, # retained filter SliverToBoxAdapter
  0xe5944007, # filter Padding
  0xe581400b, # first Column child
  0xe5832007, # children
  0xe2851a02,0xe591111b,0xe583100b, # Axis.vertical
  0xe2851901,0xe59123d3,0xe583200f, # MainAxisAlignment.start
  0xe59123c7,0xe5832013, # MainAxisSize.max
  0xe59123cf,0xe583201f, # VerticalDirection.down
  0xe2851a0d,0xe5912707,0xe5832017, # CrossAxisAlignment.stretch
  0xe2851a03,0xe5912ed3,0xe5832027, # Clip.none
  0xe1a00003,0xe24bd000,0xe8bd8800]
for i,ins in enumerate(column): original_word(0x979d6c+4*i,ins)
# Shorten tab transitions from 300ms to 100ms, using the existing Duration.
# TabController's default plus the TV detail's explicit animateTo duration.
w(0x4fb050,0xe2850a03,0xe2850a02)
w(0x4fb054,0xe5900d47,0xe590080b)
w(0x74e394,0xe285ea03,0xe285ea02)
w(0x74e398,0xe59eed47,0xe59ee80b)
# Reduce fixed 20px BoxShadow blur to 6px; retain colors, spread, border and focus scale.
focus_blurs=[]
for o in range(0x2eecf0,0xbfe690,4):
 ins=struct.unpack_from('<I',b,o)[0]
 if ins>>24 != 0xeb:continue
 rel=ins&0xffffff
 if rel&0x800000:rel-=1<<24
 if o+8+rel*4!=0xaf88ec:continue
 window=[struct.unpack_from('<I',b,x)[0] for x in range(o+4,o+164,4)]
 for k,ins2 in enumerate(window):
  at=o+4+k*4
  if ins2==0xeeb30b04 and struct.unpack_from('<I',b,at+12)[0]==0xed8c0b02:
   w(at,0xeeb30b04,0xeeb10b08)
   focus_blurs.append(hex(at))
print('Focus glow sites:',focus_blurs)
assert len(focus_blurs) == 21, 'Unexpected shadow site count'
args.output.write_bytes(b)
print('patched',sum(x!=y for x,y in zip(b,original)),'bytes')
