#!/bin/zsh
set -e
TASK=/private/tmp/anich-native
PROJECT=${ANITV_PROJECT:?Set ANITV_PROJECT}
SDK=${ANDROID_HOME:?Set ANDROID_HOME}
export JAVA_HOME=${JAVA_HOME:?Set JAVA_HOME}
python3 "$PROJECT/patch/patch_flutter_ui.py" /private/tmp/anich-tv-patch/original.apk "$TASK/libapp-ui.so"
python3 "$PROJECT/patch/patch_apk.py" /private/tmp/anich-tv-patch/original.apk "$TASK/unsigned.apk" --shim "$PROJECT/patch/libmpv.so" --dex "$PROJECT/patch/classes.dex" --bridge "$PROJECT/patch/libanichtvbridge.so" --app "$TASK/libapp-ui.so" --branding "$PROJECT/patch/branding"
"$SDK/build-tools/android-14/zipalign" -f -p 4 "$TASK/unsigned.apk" "$TASK/aligned.apk"
"$SDK/build-tools/android-14/apksigner" sign --ks "$PROJECT/signing/tv-local.jks" --ks-pass env:ANITV_KEYSTORE_PASSWORD --out "$PROJECT/AniCh-1.5.27-TV-Native-v1.apk" "$TASK/aligned.apk"
"$SDK/platform-tools/adb" -s "${ANITV_ADB_SERIAL:?Set ANITV_ADB_SERIAL}" install -r "$PROJECT/AniCh-1.5.27-TV-Native-v1.apk"
