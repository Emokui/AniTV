#!/bin/zsh
set -e
TASK=/private/tmp/anich-native
PATCH=${ANITV_PROJECT:?Set ANITV_PROJECT}/patch
export ZIG_GLOBAL_CACHE_DIR=$TASK/zig-cache
export ZIG_LOCAL_CACHE_DIR=$TASK/zig-local
ZIG=/private/tmp/anich-tv-patch/zig-macos-aarch64-0.13.0/zig
COMMON=(-target arm-linux-android -mcpu=cortex_a7 -mfloat-abi=softfp -mfpu=vfpv3-d16 -Os -s -fPIC -shared -nostdlib -Wl,--hash-style=both -Wl,-z,max-page-size=4096 -Wl,--gc-sections)
"$ZIG" cc $COMMON -Wl,-soname,libdl.so -Wl,--version-script=$PATCH/link-stub.map "$PATCH/link-stub.c" -o "$TASK/libdl.so"
"$ZIG" cc $COMMON -Wl,-soname,libc.so -Wl,--version-script=$PATCH/link-stub.map "$PATCH/link-stub.c" -o "$TASK/libc.so"
"$ZIG" cc $COMMON -I"$PATCH/jni-headers" -I${JAVA_HOME:?Set JAVA_HOME}/include -I${JAVA_HOME:?Set JAVA_HOME}/include/darwin -Wl,-soname,libanichtvbridge.so -Wl,--version-script=$PATCH/bridge.map -Wl,--no-as-needed "$PATCH/bridge.c" "$TASK/liborg.so" "$TASK/libc.so" -o "$PATCH/libanichtvbridge.so"
"$ZIG" cc $COMMON -Wl,-soname,libmpv.so -Wl,--version-script=$PATCH/shim.map -Wl,--no-as-needed "$PATCH/shim.c" "$TASK/liborg.so" "$PATCH/libanichtvbridge.so" "$TASK/libdl.so" -o "$PATCH/libmpv.so"
