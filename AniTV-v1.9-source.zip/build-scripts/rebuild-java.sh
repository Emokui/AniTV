#!/bin/zsh
set -e
JDK=${JAVA_HOME:?Set JAVA_HOME}
SDK=${ANDROID_HOME:?Set ANDROID_HOME}
TASK=/private/tmp/anich-native
PATCH=${ANITV_PROJECT:?Set ANITV_PROJECT}/patch
mkdir -p "$TASK/new-java-classes" "$TASK/new-java-dex"
"$JDK/bin/javac" -source 8 -target 8 -encoding UTF-8 -classpath "$SDK/platforms/android-34/android.jar" -d "$TASK/new-java-classes" "$PATCH/java/app/anich/"*.java
"$JDK/bin/jar" cf "$TASK/new-bridge-java.jar" -C "$TASK/new-java-classes" .
JAVA_HOME="$JDK" "$SDK/build-tools/android-14/d8" --min-api 21 --lib "$SDK/platforms/android-34/android.jar" --output "$TASK/new-java-dex" "$TASK/new-bridge-java.jar"
python3 - <<'PY'
from zipfile import ZipFile
from pathlib import Path
with ZipFile('/private/tmp/anich-tv-patch/original.apk') as src,ZipFile('/private/tmp/anich-native/java-only.apk','w') as out:
 for e in src.infolist():
  if e.filename=='classes2.dex':continue
  out.writestr(e,Path('/private/tmp/anich-native/new-java-dex/classes.dex').read_bytes() if e.filename=='classes.dex' else src.read(e))
PY
"$JDK/bin/java" -jar /private/tmp/anich-apktool.jar d -r -f -o "$TASK/new-java-decoded" "$TASK/java-only.apk" > "$TASK/new-java-decode.log" 2>&1
cp -R "$TASK/new-java-decoded/smali/app/anich/." "$TASK/work/smali/app/anich/"
"$JDK/bin/java" -jar /private/tmp/anich-apktool.jar b "$TASK/work" -o "$TASK/java-merged.apk" > "$TASK/java-build.log" 2>&1
unzip -p "$TASK/java-merged.apk" classes.dex > "$PATCH/classes.dex"
