# AniTV 极简字标

使用内置 image_gen 工具生成，未使用 CLI/API fallback。

- anitv-wordmark.png：方形原图。
- anitv-banner-source.png：16:9 横幅原图，以上一张字标为编辑目标。
- ../patch/branding：通过 macOS sips 缩放得到安装尺寸。

## 方形图标完整提示词

Use case: logo-brand. Create one production-ready square app icon for AniTV, an anime viewing app for television. The entire design is an extremely minimal typographic wordmark with the EXACT text 'AniTV' (case-sensitive), on a solid warm off-white background. One horizontal line, centered. Distinctive confident geometric sans serif typography, heavy but refined weight, tight optical kerning, elegant custom letter shapes, very legible. 'Ani' in near-black ink, 'TV' in clean vibrant blue. Wordmark occupies about 85 percent of the square width. Flat 2D graphic, crisp edges, no TV illustration, no play triangle, no antenna, no stars, no glow, no gradients, no shadows, no bevels, no 3D, no borders, no mockup, no additional wording, no decorative elements. Modern understated editorial brand identity. A clean square icon artwork, 1024 square composition.

## 横幅完整提示词

Adapt the immediately preceding minimal AniTV wordmark to a clean wide 16:9 Android TV launcher banner. Preserve the exact same AniTV lettering and case, black Ani and blue TV, flat warm off-white background. Make the wordmark large, centered, with balanced side margins and generous breathing room. No additional graphics, no borders, no effects, no gradients, no shadows, no extra wording. This is a flat graphic asset, not a mockup.
