package tv.anitv;

import android.media.MediaDataSource;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/** Bounded, seekable MP4 input. MediaDataSource selects NuPlayer on the tested Hisense TV. */
public final class RangeMediaSource extends MediaDataSource {
    static final int BLOCK = 512 * 1024;
    private static final Pattern CONTENT_RANGE = Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+|\\*)");
    private final OkHttpClient client;
    private final PlaySource source;
    private final LinkedHashMap<Long, byte[]> blocks = new LinkedHashMap<Long, byte[]>(8, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Long, byte[]> entry) { return size() > 4; }
    };
    private volatile long total = -1;
    private volatile boolean closed;
    private volatile Call active;
    public RangeMediaSource(OkHttpClient client, PlaySource source) { this.client = client; this.source = source; }
    public boolean probeIsHls() throws IOException {
        byte[] first = block(0);
        return new String(first, 0, Math.min(first.length, 128), java.nio.charset.StandardCharsets.UTF_8).trim().startsWith("#EXTM3U");
    }
    private synchronized byte[] block(long start) throws IOException {
        if (closed) throw new IOException("播放已停止");
        if (total >= 0 && start >= total) return new byte[0];
        byte[] cached = blocks.get(start); if (cached != null) return cached;
        Request.Builder request = new Request.Builder().url(source.url);
        for (Map.Entry<String, String> h : source.headers.entrySet()) request.header(h.getKey(), h.getValue());
        request.header("Accept-Encoding", "identity").header("Range", "bytes=" + start + "-" + (start + BLOCK - 1));
        Call call = client.newCall(request.build()); active = call;
        if (closed) { call.cancel(); throw new IOException("播放已停止"); }
        try (Response response = call.execute()) {
            if (response.code() == 416 && total >= 0 && start >= total) return new byte[0];
            if (response.code() != 200 && response.code() != 206) throw new IOException("视频 HTTP " + response.code());
            if (response.body() == null) throw new IOException("视频响应为空");
            if (response.code() == 206) {
                Matcher range = CONTENT_RANGE.matcher(response.header("Content-Range", ""));
                if (!range.matches() || Long.parseLong(range.group(1)) != start) throw new IOException("视频分段位置不正确");
                if (!range.group(3).equals("*")) total = Long.parseLong(range.group(3));
            } else {
                if (start != 0) throw new IOException("该线路不支持分段读取，请切换线路");
                total = response.body().contentLength();
            }
            int wanted = total >= 0 ? (int) Math.min(BLOCK, Math.max(0, total - start)) : BLOCK;
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(wanted);
            byte[] buffer = new byte[32768]; int n;
            try (java.io.InputStream in = response.body().byteStream()) {
                while (out.size() < wanted && (n = in.read(buffer, 0, Math.min(buffer.length, wanted - out.size()))) != -1) {
                    if (closed) throw new IOException("播放已停止"); out.write(buffer, 0, n);
                }
            }
            if (closed) throw new IOException("播放已停止");
            byte[] bytes = out.toByteArray();
            if (total >= 0 && bytes.length != wanted) throw new IOException("视频分段不完整，请重试");
            blocks.put(start, bytes); return bytes;
        } finally { if (active == call) active = null; }
    }
    @Override public synchronized int readAt(long position, byte[] target, int offset, int size) throws IOException {
        if (closed) throw new IOException("播放已停止");
        if (offset < 0 || size < 0 || offset > target.length - size) throw new IndexOutOfBoundsException();
        if (size == 0) return 0;
        if (position < 0 || (total >= 0 && position >= total)) return -1;
        byte[] bytes = block(position / BLOCK * BLOCK); int inside = (int) (position % BLOCK);
        if (inside >= bytes.length) return -1;
        int count = Math.min(size, bytes.length - inside); System.arraycopy(bytes, inside, target, offset, count); return count;
    }
    @Override public long getSize() { return total; }
    @Override public void close() { closed = true; Call call = active; NetworkCleanup.cancel(call); }
}
