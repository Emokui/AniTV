package tv.anitv;

import static org.junit.Assert.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.Shadows;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28, application=AniApp.class, qualifiers="w960dp-h540dp-land")
public class EpisodeNavigationTest {
    private void layout(AlertDialog dialog) {
        View root=dialog.getWindow().getDecorView();
        root.measure(View.MeasureSpec.makeMeasureSpec(960,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(540,View.MeasureSpec.EXACTLY));
        root.layout(0,0,960,540);Shadows.shadowOf(Looper.getMainLooper()).idle();
    }
    @Test public void downFromRightColumnReachesIncompleteLastRowAndUpReturns() {
        try(ActivityController<Activity> controller=Robolectric.buildActivity(Activity.class).setup().visible()) {
            List<Episode> episodes=new ArrayList<>();for(int i=1;i<=6;i++)episodes.add(new Episode(i,"第"+i+"集"));
            AlertDialog dialog=EpisodePicker.create(controller.get(),"导航测试",episodes,3,index->{});
            dialog.show();layout(dialog);
            try {
                RecyclerView grid=dialog.findViewById(android.R.id.content).findViewWithTag("episode-grid");
                View fourth=grid.findViewHolderForAdapterPosition(3).itemView;
                fourth.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_DOWN));layout(dialog);
                View last=grid.findViewHolderForAdapterPosition(5).itemView;assertTrue(last.hasFocus());
                last.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_UP));layout(dialog);
                assertTrue(grid.findViewHolderForAdapterPosition(1).itemView.hasFocus());
            } finally {dialog.dismiss();}
        }
    }
}
